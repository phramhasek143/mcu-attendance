---
name: MCU Academic Saffron
colors:
  surface: '#f8f9ff'
  surface-dim: '#ccdbf3'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e6eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d5e3fc'
  on-surface: '#0d1c2e'
  on-surface-variant: '#554336'
  inverse-surface: '#233144'
  inverse-on-surface: '#eaf1ff'
  outline: '#887364'
  outline-variant: '#dbc2b0'
  surface-tint: '#904d00'
  primary: '#8d4b00'
  on-primary: '#ffffff'
  primary-container: '#b15f00'
  on-primary-container: '#fffbff'
  inverse-primary: '#ffb77d'
  secondary: '#545f73'
  on-secondary: '#ffffff'
  secondary-container: '#d5e0f8'
  on-secondary-container: '#586377'
  tertiary: '#825100'
  on-tertiary: '#ffffff'
  tertiary-container: '#a36700'
  on-tertiary-container: '#fffbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdcc3'
  primary-fixed-dim: '#ffb77d'
  on-primary-fixed: '#2f1500'
  on-primary-fixed-variant: '#6e3900'
  secondary-fixed: '#d8e3fb'
  secondary-fixed-dim: '#bcc7de'
  on-secondary-fixed: '#111c2d'
  on-secondary-fixed-variant: '#3c475a'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#f8f9ff'
  on-background: '#0d1c2e'
  surface-variant: '#d5e3fc'
  saffron-deep: '#B45309'
  saffron-light: '#FEF3C7'
  navy-ink: '#0F172A'
  surface-ivory: '#F8FAFC'
  surface-card: '#FFFFFF'
  status-present: '#10B981'
  status-present-soft: '#D1FAE5'
  status-warning: '#F59E0B'
  status-warning-soft: '#FEF3C7'
  status-absent: '#EF4444'
  status-absent-soft: '#FEE2E2'
  status-excused: '#6366F1'
  status-excused-soft: '#EEF2FF'
typography:
  display-lg:
    fontFamily: Prompt
    fontSize: 48px
    fontWeight: '600'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Prompt
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Prompt
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Prompt
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-md:
    fontFamily: Prompt
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
  headline-sm:
    fontFamily: Prompt
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 28px
  title-md:
    fontFamily: Prompt
    fontSize: 18px
    fontWeight: '500'
    lineHeight: 26px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.03em
  data-mono:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  space-2xs: 0.25rem
  space-xs: 0.5rem
  space-sm: 0.75rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
  gutter-mobile: 1rem
  gutter-desktop: 1.5rem
  max-content-width: 1280px
  max-qr-display-width: 480px
---

## Brand & Style

The design system embodies the dignified fusion of venerable Thai Buddhist scholastic traditions and precise modern higher-education governance. Tailored for Mahachulalongkornrajavidyalaya University (MCU), it serves a dual population of monastic scholars (พระนิสิต, พระสังฆาธิการ) and lay students, academic faculty, and registrars. The visual persona is scholarly, reverent, and disciplined, yet distinctly technologically agile. 

Drawing from **Corporate / Modern** principles infused with refined academic warmth, the design avoids transient tech gimmicks in favor of structural clarity, high contrast, and serene composure. The core palette balances sacred Saffron Amber with deep scholarly slate, instilling respect and reliability across both digital high-frequency capture surfaces (such as synchronized dynamic QR projection) and bureaucratic workflows. 

The emotional tone evokes calm certainty, fairness, and absolute regulatory transparency. Because academic attendance carries legal ramifications under university bylaws and national higher education standards (the strict 80% examination eligibility threshold), every status indicator, badge, and threshold alert must deliver instant, unambiguous feedback without sensory overload.

## Colors

The chromatic architecture establishes an authoritative hierarchy structured around monastic saffron and scholarly slate:

- **Primary (`#D97706`)**: Saffron Amber serves as the primary focal tone for key calls to action, brand markers, active navigation states, and identity landmarks.
- **Secondary (`#1E293B`)**: Academic Deep Slate functions as the structural anchoring tone, establishing solemn typographic weight, solid headers, and navigation frame backdrops.
- **Tertiary (`#F59E0B`)**: Warm Gold accents provide secondary emphasis, interactive focus highlights, and intermediate threshold cues.
- **Neutral (`#475569`)**: Balanced Slate Neutral governs secondary text, structural divider lines, subtle card perimeters, and de-emphasized metadata.

### Academic & Regulatory Semantic Thresholds
The attendance engine calculates strict regulatory thresholds mandated by higher education standards:
- **Eligible / Normal ($\ge 85\%$)**: `status-present` (`#10B981`) with soft background fill `status-present-soft` (`#D1FAE5`).
- **Warning / Near Minimum ($80.0\% - 84.9\%$)**: `status-warning` (`#F59E0B`) with soft background fill `status-warning-soft` (`#FEF3C7`).
- **Critical / Ineligible ($< 80.0\%$)**: `status-absent` (`#EF4444`) with soft background fill `status-absent-soft` (`#FEE2E2`).
- **Approved / Excused Leave**: `status-excused` (`#6366F1`) paired with `status-excused-soft` (`#EEF2FF`).

### Monochrome & Print Safe Fallback
For printable A4 rosters, official registrar exports, and zero-tech analog sign-off sheets, the palette defaults to high-contrast monochrome (`#0F172A` on `#FFFFFF`) with crisp pure-black line work, stripping away colored backgrounds to conserve toner and guarantee legibility when photocopied.

## Typography

The typographic hierarchy accommodates bilingual Thai-Latin balance with rigorous attention to academic honorifics and technical verification strings.

- **Headlines & Section Titles (Prompt)**: Chosen for its clean, geometric humanist Thai glyph geometry, providing immediate authority and modern legibility across university portal headings without decorative distraction.
- **Body & Controls (Inter)**: Delivers unmatched cross-platform micro-legibility for table grids, status descriptions, inputs, and dense audit logs. When paired with Thai fallback fonts, line heights are adjusted to `1.5x`–`1.6x` to prevent clipping of upper and lower Thai tone marks (วรรณยุกต์ / สระ).
- **Data & Verification (JetBrains Mono)**: Reserved for dynamic QR HMAC tokens, student identification codes, time-stamps, and network payload hashes.

### Monastic & Ecclesiastical Honorific Formatting
The platform mandates specialized typographical treatment for ecclesiastical titles:
- Monk designations (e.g., *พระมหา, พระครู, เจ้าคุณ*, followed by monastic sobriquet *ฉายา* such as *ฐิตธมฺโม*) must remain bound to the proper noun without breaking across line wrapping.
- In student lists and profile badges, the monastic title is set with `label-md` in secondary slate, while the Dharma name (`ฉายา`) maintains `title-md` emphasis to respect ecclesiastical hierarchy alongside civil registration IDs.

## Layout & Spacing

The layout is built upon an 8-point base grid system, ensuring mathematical rhythm between compact audit tables and expansive classroom presentation modes.

### Structural Breakpoints
- **Mobile (up to 639px)**: Single-column fluid stack with `1rem` edge margins. Primary view accommodates student one-tap check-in, dynamic QR camera viewfinder, and personal threshold summary cards.
- **Tablet (640px to 1023px)**: 8-column layout with `1.25rem` gutters. Accommodates attendance rosters, filter bars, and quick inline overrides for professors.
- **Desktop (1024px and above)**: 12-column fixed-max layout centered at `1280px` with `1.5rem` gutters. Houses dual-pane registrar dashboards, deep statistical analytics, and split views.
- **Projection Presentation Mode**: Dedicated ultra-focused viewport layout constrained to `max-qr-display-width` (`480px`) centered on an uncluttered canvas, designed for auditorium projectors and overhead screens to ensure fast camera scanning from distant classroom seating.

## Elevation & Depth

Elevation strictly reinforces functional hierarchy rather than decorative styling, utilizing tonal layering paired with soft slate-tinted ambient drop shadows:

- **Level 0 (Flat / Canvas)**: Ivory/Slate-50 background (`#F8FAFC`) without shadow. Standard page background for portals and dashboard layouts.
- **Level 1 (Subtle Cards & Lists)**: Card surfaces (`#FFFFFF`) framed by a low-contrast border (`1px solid #E2E8F0`) and an ambient shadow (`0 1px 3px 0 rgba(15, 23, 42, 0.04), 0 1px 2px -1px rgba(15, 23, 42, 0.04)`). Used for student roster rows, basic configuration panels, and statistical modules.
- **Level 2 (Active QR & Interactive Cards)**: Floating interactive elements, active dynamic QR presentation modules, and open popovers utilize an expanded ambient shadow (`0 10px 15px -3px rgba(15, 23, 42, 0.08), 0 4px 6px -4px rgba(15, 23, 42, 0.04)`).
- **Level 3 (Modals & Overlays)**: Modal dialogs, session revocation alerts, and critical academic warning prompts use high elevation (`0 20px 25px -5px rgba(15, 23, 42, 0.12), 0 8px 10px -6px rgba(15, 23, 42, 0.06)`) flanked by a 40% opacity slate backdrop overlay (`#0F172A`).

## Shapes

The interface implements a balanced `roundedness: 2` scale, pairing approachable rounded corners with structured institutional geometry:

- **Base Radius (0.5rem / 8px)**: Standard for inputs, buttons, status chips, table containers, and interactive list items.
- **Large Radius (1rem / 16px)**: Applied to high-level content cards, statistical metric widgets, dynamic QR projection containers, and dialog modal windows.
- **Pill Radius (Full / 9999px)**: Exclusively reserved for semantic status badges (e.g., "เข้าเรียนปกติ", "ขาดเรียน", "ลาป่วย") and countdown timer progress rings, distinguishing categorical status chips from rectangular actionable buttons.

## Components

### Buttons
- **Primary**: Solid Saffron Amber (`#D97706`), bold white text, subtle hover shift to `#B45309`. Used for major session actions (e.g., "เปิดห้องเรียน", "บันทึกเวลา").
- **Secondary**: Deep Slate outline (`#1E293B`) or ghost border with `#0F172A` text, shifting to a 5% slate fill on hover. Used for filters, exports, and secondary navigation.
- **Danger**: Clean `#EF4444` solid or bordered style reserved exclusively for irreversible actions like "ยกเลิกคาบเรียน" or "ตัดสิทธิ์สอบ".

### Dynamic QR Code Presentation Card
- Encased in a Level 2 elevated card (`#FFFFFF`) with `1rem` radius.
- Displays high-contrast black QR pattern (`#0F172A`) against pure white background with a generous 16px safe-zone quiet border.
- Features a synchronized radial circular countdown timer tracking the dynamic rotation window (20 seconds HMAC cycle) accompanied by a linear bar showing Redis cache TTL (25 seconds).

### Semantic Attendance Status Chips
- Height of 28px, pill-rounded (`9999px`), padding `0 12px`, typography `label-sm`.
- **Present ($\ge 85\%$)**: `status-present-soft` background with `status-present` border and text.
- **Warning ($80.0\% - 84.9\%$)**: `status-warning-soft` background with `status-warning` text.
- **Critical / Ineligible ($< 80\%$)**: `status-absent-soft` background with `status-absent` text.
- **Excused Leave**: `status-excused-soft` background with `status-excused` text.

### Attendance Threshold Metric Gauge
- A composite component showing the student's current percentage against the mandatory 80% baseline.
- Includes a horizontal progress track with a visually pinned indicator at exactly the 80.0% boundary mark.
- Dynamic color-shifting track: shifts from red to amber to emerald as the student's attendance passes regulatory thresholds.

### Roster Tables & Honorific Row Lists
- Alternating row zebra subtle shading (`#FFFFFF` to `#F8FAFC`).
- Student profile column clearly presents civil title, monk title (`ฉายา`), academic rank, and student ID.
- Right-aligned quick-action toggle controls for manual override by the course instructor.

### Printable Sign-off Sheet Layout (A4 Format)
- Dedicated print stylesheet view stripping shadows, cards, and colors.
- Strict black-and-white grid lines (`1px solid #000000`) with designated signature columns for monk and lay student physical endorsements.